﻿import React, { useEffect, useState, useRef } from 'react';
import LogsList from './components/LogsList';
import AlertToast from './components/AlertToast';

const LOKI_BASE = import.meta.env.VITE_LOKI_URL || 'http://localhost:3100';
const ALERT_WINDOW_MINUTES = Number(import.meta.env.VITE_ALERT_WINDOW_MINUTES || 5);
const ALERT_THRESHOLD = Number(import.meta.env.VITE_ALERT_THRESHOLD || 30);

// a simple LogQL - adjust as needed
const LOGQL = '{job="cowrie"} |= "login attempt"';

export default function App() {
  const [logs, setLogs] = useState([]);
  const [alertMsg, setAlertMsg] = useState('');
  const polling = useRef(null);

  async function fetchLogs() {
    try {
      // compute epoch ns as BigInt
      const end = BigInt(Date.now()) * 1000000n;
      const start = end - BigInt(ALERT_WINDOW_MINUTES * 60 * 1e9);

      const q = encodeURIComponent(LOGQL);
      const url = `${LOKI_BASE}/loki/api/v1/query_range?query=${q}&limit=500&start=${start}&end=${end}`;
      const res = await fetch(url);
      const j = await res.json();

      const streams = j.data?.result || [];
      // flatten values arrays to simple pairs [ts,msg]
      const entries = streams.flatMap(s => (s.values || []).map(v => [v[0], v[1]]));
      setLogs(entries.slice().reverse());

      // simple alert condition: number of log lines in window
      if (entries.length >= ALERT_THRESHOLD) {
        setAlertMsg(`High login attempts: ${entries.length} attempts in last ${ALERT_WINDOW_MINUTES} min`);
      } else {
        setAlertMsg('');
      }
    } catch (err) {
      console.error('fetchLogs err', err);
    }
  }

  useEffect(() => {
    fetchLogs();
    polling.current = setInterval(fetchLogs, 10_000); // every 10s
    return () => clearInterval(polling.current);
  }, []);

  return (
    <div style={{fontFamily:'Inter, system-ui, Arial', padding:'1rem', background:'#071127', minHeight:'100vh', color:'#e7f0ff'}}>
      <h1 style={{margin:'0 0 1rem 0'}}>Honeynet — Live Logs</h1>
      <div style={{display:'grid', gridTemplateColumns:'1fr 360px', gap:'1rem', alignItems:'start'}}>
        <div>
          <h3 style={{margin:'0 0 0.5rem 0'}}>Latest logs</h3>
          <LogsList entries={logs} />
        </div>

        <aside>
          <h3 style={{margin:'0 0 0.5rem 0'}}>Status</h3>
          <div style={{padding:'0.6rem', borderRadius:'8px', background:'#031021', minHeight:'120px'}}>
            <div>Loki: {LOKI_BASE}</div>
            <div>Window: {ALERT_WINDOW_MINUTES} min</div>
            <div>Threshold: {ALERT_THRESHOLD}</div>
            <div style={{marginTop:'0.6rem', opacity:0.9}}>Logs in window: {logs.length}</div>
          </div>
        </aside>
      </div>

      <AlertToast message={alertMsg} onClose={() => setAlertMsg('')} severity="warning" />
    </div>
  );
}
