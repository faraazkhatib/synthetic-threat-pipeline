﻿import React from 'react';

export default function LogsList({ entries = [] }) {
  return (
    <div className='logs-list' style={{maxHeight: '60vh', overflowY: 'auto', padding: '0.5rem', background:'#0b1220', color:'#e6eef8', borderRadius:'8px'}}>
      {entries.length === 0 ? (
        <div style={{opacity:0.7}}>No logs</div>
      ) : (
        <ul style={{listStyle:'none', padding:0, margin:0}}>
          {entries.map((e, i) => (
            <li key={i} style={{padding:'0.4rem 0', borderBottom: '1px solid rgba(255,255,255,0.03)'}}>
              <div style={{fontSize:'0.85rem', color:'#cfe6ff'}}>{e[1] ?? e}</div>
              <div style={{fontSize:'0.72rem', color:'#9fb7d8'}}>{e[0]}</div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
