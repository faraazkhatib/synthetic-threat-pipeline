﻿import React from 'react';

export default function AlertToast({ message = '', onClose = () => {}, severity = 'info' }) {
  if (!message) return null;

  return (
    <div
      className={`alert-toast alert-${severity}`}
      role="status"
      aria-live="polite"
      style={{
        position: 'fixed',
        top: '1rem',
        right: '1rem',
        zIndex: 1000,
      }}
    >
      <div style={{
        background: '#0f1724',
        color: '#e7f0ff',
        padding: '0.75rem 1rem',
        borderRadius: 8,
        boxShadow: '0 8px 24px rgba(2,6,23,0.6)',
        minWidth: 260,
      }}>
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', gap:8}}>
          <strong style={{fontSize:12, letterSpacing:0.6}}>{severity.toUpperCase()}</strong>
          <button
            onClick={onClose}
            style={{
              background: 'transparent',
              border: 'none',
              color: '#9fb0d9',
              cursor: 'pointer',
              fontSize: 12,
              padding: '2px 6px',
            }}
            aria-label="close"
          >
            ✕
          </button>
        </div>

        <div style={{marginTop:8, fontSize:13, lineHeight:1.3}}>
          {message}
        </div>
      </div>
    </div>
  );
}
